from setuptools import setup
setup(
    name='pymdown_extras',
    version='1.0.0',
    py_modules=['collapse_code'],
    install_requires=['pymdown-extensions>=10.7'],
)
